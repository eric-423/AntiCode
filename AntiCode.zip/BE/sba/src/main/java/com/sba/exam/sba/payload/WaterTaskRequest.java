package com.sba.exam.sba.payload;

import lombok.Data;

@Data
public class WaterTaskRequest {
    private int waterId;
    private float volumn;
}
