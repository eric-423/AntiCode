package com.sba.exam.sba.payload;

import lombok.Data;

@Data
public class PlantPotTaskRequest {
    private int plantPotId;
    private int quantity;
}
