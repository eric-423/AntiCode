package com.sba.exam.sba.dto;


import lombok.Data;

@Data
public class ChemicalTypeDTO {
    private int id;
    private String name;
    private String description;


}
