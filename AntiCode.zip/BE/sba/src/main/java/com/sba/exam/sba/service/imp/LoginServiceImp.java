package com.sba.exam.sba.service.imp;

public interface LoginServiceImp {
        boolean checkLogin(String username,String password);
}
