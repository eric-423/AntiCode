package com.sba.exam.sba.payload;

import lombok.Data;

@Data
public class ChemicalTaskRequest {
    private int chemicalId;
    private float volumn;
}
