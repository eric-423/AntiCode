package com.sba.exam.sba.repository;

import com.sba.exam.sba.entity.PlantType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlantTypeRepository extends JpaRepository<PlantType, Integer> {
}
