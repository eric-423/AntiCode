package com.sba.exam.sba.payload;

import lombok.Data;

@Data
public class PlantMediumTaskRequest {
    private int plantMediumId;
    private float mediumWeight;
}
