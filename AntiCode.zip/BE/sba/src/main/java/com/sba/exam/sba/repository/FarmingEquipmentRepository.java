package com.sba.exam.sba.repository;

import com.sba.exam.sba.entity.FarmingEquipment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FarmingEquipmentRepository extends JpaRepository<FarmingEquipment, Integer> {
}
