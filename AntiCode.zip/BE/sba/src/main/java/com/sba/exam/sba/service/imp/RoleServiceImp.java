package com.sba.exam.sba.service.imp;

import com.sba.exam.sba.dto.RoleDTO;

import java.util.List;

public interface RoleServiceImp {
    List<RoleDTO> getRoles();
}
