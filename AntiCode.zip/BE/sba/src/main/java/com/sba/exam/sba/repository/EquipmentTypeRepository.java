package com.sba.exam.sba.repository;

import com.sba.exam.sba.entity.EquipmentType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EquipmentTypeRepository extends JpaRepository<EquipmentType, Integer> {
}
