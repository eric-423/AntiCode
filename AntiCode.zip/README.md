## ALTERNATIVE EVENT:
- Xuất hiện conflict source
- reset head về trước đó 2 function task và chemical task: contributor (Hiếu, Huy)
- Nhựt thực hiện resolve conflict nên tất cả contributors đang tính sai: đang tính hết cho Nhựt
    + Bước 1: git reset về HEAD fb17249c48ab3470717aa77185dcac8b36c7e9d1
    + Bước 2: đọc tất cả các file thay đổi thực hiện thay đổi thủ công
    + Bước 3: commit lần 1 khoảng 90 file và commit lần 2 khoảng 18 file
    + Bước 4: thực hiện push force

- Expected contributor: Hiếu (+ more 1k line code, more 2 commit) | Huy (+ more 2k line code, more 2 commit)
=> Hiện tại contributor đang tính sai
=> Resolve conflict resource done: 12:16 23/02/2025
