const ROLES = {
    ADMIN: "Admin",
    MANAGER: "Manager",
    WORKER: "Worker"
}

export default ROLES