const BASE_URL =  import.meta.env.VITE_REACT_APP_END_POINT;

const BASE = {
    BASE_URL
}

export default BASE;