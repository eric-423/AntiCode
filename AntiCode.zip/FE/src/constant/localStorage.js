const LOCALSTORAGE = {
    GUEST_REGISTER_INFORMATION: "guest_register_information",
    ACCOUNT_LOGIN_INFORMATION: "_a",
    REFRESH_TASKS_DATA: "refresh_task_data",
    REFRESH_TASK_USER: "refresh_task_user",
    REFRESH_TASK_MANAGER: "refresh_task_manager"
}

export default LOCALSTORAGE