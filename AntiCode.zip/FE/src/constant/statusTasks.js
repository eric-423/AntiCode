const STATUS_TASKS = {
  INITIAL: "Initial",
  TASK_READY: "Task Ready",
  ON_PROGRESS: "On Progress",
  NEEDS_REVIEW: "Needs Review",
  DONE: "Done",
};

export default STATUS_TASKS