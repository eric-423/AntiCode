import React from 'react'
import './Report.css'

const Report = () => {
  return (
    <div className='report-plans-planting'>
        <div className='card-report-plans-planting'>
            <h5>Plans Actives</h5>
        </div>
    </div>
  )
}

export default Report