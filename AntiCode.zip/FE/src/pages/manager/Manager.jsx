import Navigation from '../../components/manager/navigation/Navigation'

const Manager = () => {
  return (
    <Navigation />
  )
}

export default Manager